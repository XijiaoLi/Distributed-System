#!/bin/bash

for t in  TestLimp # TestConcurrentUnreliable #TestConcurrent TestBasic TestMove
# for t in TestRPCCount
do
  echo $t
  count=0
  n=50
  for i in $(seq 1 $n)
  do
    go test -run "^${t}$" -timeout 40s > ${i}.txt
    result=$(grep -E '^PASS$' ${i}.txt | wc -l)
    count=$((count + result))
    if [ $result -eq 1 ]; then
      echo "$i, "
      rm ${i}.txt
      # mkdir ./log-${t}-${i}
      # cp *.txt ./log-${t}-${i}
    fi
    # rm *.txt
  done
  echo "$count/$n"
done
